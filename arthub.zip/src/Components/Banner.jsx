"use client";

import Image from 'next/image'
import React, { useState, useEffect } from 'react'
import { ArrowRight } from 'lucide-react' 
import Hero1 from '../../public/Assets/Hero1.png'
import Hero2 from '../../public/Assets/Hero2.png'
import Hero3 from '../../public/Assets/Hero3.png'
import HeroTooltip1 from '../../public/Assets/HeroTooltip1.png'
import HeroTooltip2 from '../../public/Assets/HeroToolTip2.png'

const Banner = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      title: "The Renaissance of",
      titleHighlight: "Digital Art",
      highlightColor: "text-violet-600",
      description: "Discover a new era where classical techniques meet cutting-edge technology. Experience curation at its finest.",
      image: Hero1,
    },
    {
      id: 2,
      title: "Abstract",
      titleHighlight: "Emotions",
      highlightColor: "text-pink-600",
      description: "Visualizing the unseen. Dive into a collection of abstract works that challenge perception and spark conversation.",
      image: Hero2,
    },
    {
      id: 3,
      title: "Modern",
      titleHighlight: "Sculptures",
      highlightColor: "text-teal-700",
      description: "Redefining space and form through digital three-dimensional masterpieces. Collect the impossible.",
      image: Hero3,
    },
  ];

  // অটো-স্লাইড টাইমার (৩ সেকেন্ড পর পর)
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prevSlide) =>
        prevSlide === slides.length - 1 ? 0 : prevSlide + 1
      );
    }, 3000);

    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="w-full relative select-none overflow-hidden min-h-[calc(100vh-72px)] bg-slate-950/5">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(168,85,247,0.22),_transparent_30%),radial-gradient(circle_at_top_right,_rgba(236,72,153,0.18),_transparent_25%),radial-gradient(circle_at_bottom_left,_rgba(14,165,233,0.12),_transparent_22%)]" />
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/10 via-transparent to-slate-950/40" />

      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${
            index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          {/* ব্যাকগ্রাউন্ড hero ইমেজ */}
          <div className="absolute inset-0">
            <Image
              src={slide.image}
              alt={slide.title}
              fill
              priority={index === 0}
              className="object-cover object-center"
            />
          </div>

          <div className="w-full max-w-[88%] md:max-w-[84%] lg:max-w-[80%] mx-auto h-full relative z-20 grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-8 items-center py-10">

            {/* বাম পাশের টেক্সট কন্টেন্ট */}
            <div className="max-w-[95%] sm:max-w-[75%] md:max-w-[60%] lg:max-w-[55%] flex flex-col justify-center py-4 rounded-xl">
              <p className="text-sm uppercase tracking-[0.32em] text-violet-300">
                Explore curated digital art
              </p>
              <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-[72px] font-extrabold text-white tracking-tight leading-tight">
                {slide.title} <br />
                <span className={slide.highlightColor}>{slide.titleHighlight}</span>
              </h1>

              <p className="mt-4 text-base sm:text-lg md:text-xl text-slate-200/90 leading-relaxed font-medium">
                {slide.description}
              </p>

              <div className="mt-8">
                <button className="flex items-center gap-2 px-6 py-3.5 bg-violet-600 text-white font-semibold rounded-xl shadow-md hover:bg-violet-700 transition-all duration-200">
                  Browse Artworks
                  <ArrowRight size={18} />
                </button>
              </div>
            </div>

            {/* ডান পাশের টুলটিপ কার্ড — fix: overflow-hidden + w-full h-auto */}
            <div className="hidden md:block relative h-[440px] lg:h-[520px]">
              <div className="absolute left-0 top-10 w-[170px] sm:w-[210px] md:w-[240px] rounded-[32px] border border-white/10 bg-slate-950/85 p-4 shadow-2xl backdrop-blur-xl overflow-hidden">
                <Image
                  src={HeroTooltip1}
                  alt="Art Card 1"
                  width={240}
                  height={320}
                  className="w-full h-auto rounded-[28px] object-cover"
                />
              </div>

              <div className="absolute left-1/4 top-24 w-[160px] sm:w-[190px] md:w-[220px] rounded-[28px] border border-white/15 bg-white p-3 shadow-2xl overflow-hidden">
                <Image
                  src={HeroTooltip2}
                  alt="Art Card 2"
                  width={220}
                  height={260}
                  className="w-full h-auto rounded-[24px] object-cover"
                />
              </div>
              <div className="absolute right-0 bottom-10 h-36 w-36 rounded-full bg-violet-500/10 blur-3xl" />
            </div>

            {/* ডট ইন্ডিকেটর */}
            <div className="absolute bottom-8 left-0 flex gap-3 z-30">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`h-2.5 rounded-full transition-all duration-300 ${
                    index === currentSlide ? "w-10 bg-violet-500" : "w-3 bg-slate-200/50"
                  }`}
                />
              ))}
            </div>

          </div>
        </div>
      ))}

    </div>
  )
}

export default Banner;